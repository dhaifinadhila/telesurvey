<?
	include_once("config.php");
	include_once("common.php");
	echo "<pre>";
	$data = searchNIPBawahan_ByNIP('5784995P');
	print_r($data);
	echo "</pre>";	
	$data_struktural = searchJenjang_byNIP('5784995P');
	print_r($data_struktural);
	
	
	
	
?>