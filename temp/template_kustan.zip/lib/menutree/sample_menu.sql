CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(5) NOT NULL auto_increment,
  `parent_id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `url` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ;

INSERT INTO `menu` (`id`, `parent_id`, `name`, `url`) VALUES
(1, 0, 'Home', '?page=home'),
(2, 0, 'Profile', '?page=profile'),
(3, 0, 'Branch', '#'),
(4, 3, 'Jakarta', '?page=branch&id=jakarta'),
(5, 3, 'Bandung', '?page=branch&id=bandung'),
(6, 3, 'Medan', '?page=branch&id=medan'),
(7, 0, 'Product', ''),
(8, 7, 'Food', '?page=product&id=food'),
(9, 7, 'Logistic', '?page=product&id=logistic'),
(10, 7, 'Merchant', '?page=product&id=merchant'),
(11, 7, 'Furniture', '?page=product&id=furniture'),
(12, 0, 'Links', '?page=links'),
(13, 0, 'Contact Us', '?page=contact'),
(14, 8, 'Meat', '?page=product&id=food&c=meat'),
(15, 8, 'Drink', '?page=product&id=food&c=drink'),
(16, 4, 'Branch No 1', '?page=branch&id=jakarta&c=1'),
(17, 4, 'Branch No 2', '?page=branch&id=jakarta&c=2');
