<?

function select_tagihan(){ 
	$sql="SELECT * FROM tagihan" ;
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_tagihan_by_id_tagihan($var_id_tagihan){ 
	$sql="SELECT * FROM tagihan WHERE id_tagihan = '" .mysql_real_escape_string(trim($var_id_tagihan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_tagihan_by_id_vendor($var_id_vendor){ 
	$sql="SELECT * FROM tagihan WHERE id_vendor = '" .mysql_real_escape_string(trim($var_id_vendor)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_tagihan_by_id_spk($var_id_spk){ 
	$sql="SELECT * FROM tagihan WHERE id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_tagihan_by_nomor_kuitansi($var_nomor_kuitansi){ 
	$sql="SELECT * FROM tagihan WHERE nomor_kuitansi = '" .mysql_real_escape_string(trim($var_nomor_kuitansi)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_tagihan_by_rekening_tujuan($var_rekening_tujuan){ 
	$sql="SELECT * FROM tagihan WHERE rekening_tujuan = '" .mysql_real_escape_string(trim($var_rekening_tujuan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_tagihan_by_rekening_nama($var_rekening_nama){ 
	$sql="SELECT * FROM tagihan WHERE rekening_nama = '" .mysql_real_escape_string(trim($var_rekening_nama)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_tagihan_by_rupiah_tagihan($var_rupiah_tagihan){ 
	$sql="SELECT * FROM tagihan WHERE rupiah_tagihan = '" .mysql_real_escape_string(trim($var_rupiah_tagihan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_tagihan_by_tanggal_dikirim_tagihan($var_tanggal_dikirim_tagihan){ 
	$sql="SELECT * FROM tagihan WHERE tanggal_dikirim_tagihan = '" .mysql_real_escape_string(trim($var_tanggal_dikirim_tagihan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_tagihan_by_tanggal_diterima_tagihan($var_tanggal_diterima_tagihan){ 
	$sql="SELECT * FROM tagihan WHERE tanggal_diterima_tagihan = '" .mysql_real_escape_string(trim($var_tanggal_diterima_tagihan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}



function delete_tagihan_by_id_tagihan($var_id_tagihan){ 
	$sql="DELETE FROM tagihan WHERE id_tagihan = " .mysql_real_escape_string(trim($var_id_tagihan)). " LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnDetete_tagihan=1; } else { $returnDetete_tagihan=0; }
	return $returnDetete_tagihan;
}

function insert_tagihan($var_id_vendor,$var_id_spk,$var_nomor_kuitansi,$var_rekening_tujuan,$var_rekening_nama,$var_rupiah_tagihan,$var_tanggal_dikirim_tagihan,$var_tanggal_diterima_tagihan){ 
	$sql="INSERT INTO tagihan (id_tagihan,id_vendor,id_spk,nomor_kuitansi,rekening_tujuan,rekening_nama,rupiah_tagihan,tanggal_dikirim_tagihan,tanggal_diterima_tagihan) VALUES (NULL,'" .mysql_real_escape_string(trim($var_id_vendor)). "','" .mysql_real_escape_string(trim($var_id_spk)). "','" .mysql_real_escape_string(trim($var_nomor_kuitansi)). "','" .mysql_real_escape_string(trim($var_rekening_tujuan)). "','" .mysql_real_escape_string(trim($var_rekening_nama)). "','" .mysql_real_escape_string(trim($var_rupiah_tagihan)). "','" .mysql_real_escape_string(trim($var_tanggal_dikirim_tagihan)). "','" .mysql_real_escape_string(trim($var_tanggal_diterima_tagihan)). "')";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnInsert_tagihan=1; } else { $returnInsert_tagihan=0; }
	return $returnInsert_tagihan;
}

function update_tagihan($var_id_tagihan,$var_id_vendor,$var_id_spk,$var_nomor_kuitansi,$var_rekening_tujuan,$var_rekening_nama,$var_rupiah_tagihan,$var_tanggal_dikirim_tagihan,$var_tanggal_diterima_tagihan){ 
	$sql="UPDATE tagihan SET id_vendor = '" .mysql_real_escape_string(trim($var_id_vendor)). "', id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "', nomor_kuitansi = '" .mysql_real_escape_string(trim($var_nomor_kuitansi)). "', rekening_tujuan = '" .mysql_real_escape_string(trim($var_rekening_tujuan)). "', rekening_nama = '" .mysql_real_escape_string(trim($var_rekening_nama)). "', rupiah_tagihan = '" .mysql_real_escape_string(trim($var_rupiah_tagihan)). "', tanggal_dikirim_tagihan = '" .mysql_real_escape_string(trim($var_tanggal_dikirim_tagihan)). "', tanggal_diterima_tagihan = '" .mysql_real_escape_string(trim($var_tanggal_diterima_tagihan)). "' WHERE id_tagihan = '" .mysql_real_escape_string(trim($var_id_tagihan)). "' LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnUpdate_tagihan=1; } else { $returnUpdate_tagihan=0; }
	return $returnUpdate_tagihan;
}

?>