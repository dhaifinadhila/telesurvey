<?

function select_bastp(){ 
	$sql="SELECT * FROM bastp" ;
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bastp_by_id_bastp($var_id_bastp){ 
	$sql="SELECT * FROM bastp WHERE id_bastp = '" .mysql_real_escape_string(trim($var_id_bastp)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bastp_by_nomor_bastp($var_nomor_bastp){ 
	$sql="SELECT * FROM bastp WHERE nomor_bastp = '" .mysql_real_escape_string(trim($var_nomor_bastp)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bastp_by_tanggal_bastp($var_tanggal_bastp){ 
	$sql="SELECT * FROM bastp WHERE tanggal_bastp = '" .mysql_real_escape_string(trim($var_tanggal_bastp)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bastp_by_direksi_pekerjaan($var_direksi_pekerjaan){ 
	$sql="SELECT * FROM bastp WHERE direksi_pekerjaan = '" .mysql_real_escape_string(trim($var_direksi_pekerjaan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bastp_by_direksi_vendor($var_direksi_vendor){ 
	$sql="SELECT * FROM bastp WHERE direksi_vendor = '" .mysql_real_escape_string(trim($var_direksi_vendor)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bastp_by_file_bapp($var_file_bapp){ 
	$sql="SELECT * FROM bastp WHERE file_bapp = '" .mysql_real_escape_string(trim($var_file_bapp)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bastp_by_keterangan($var_keterangan){ 
	$sql="SELECT * FROM bastp WHERE keterangan = '" .mysql_real_escape_string(trim($var_keterangan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bastp_by_user_input($var_user_input){ 
	$sql="SELECT * FROM bastp WHERE user_input = '" .mysql_real_escape_string(trim($var_user_input)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bastp_by_user_input_date($var_user_input_date){ 
	$sql="SELECT * FROM bastp WHERE user_input_date = '" .mysql_real_escape_string(trim($var_user_input_date)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}



function delete_bastp_by_id_bastp($var_id_bastp){ 
	$sql="DELETE FROM bastp WHERE id_bastp = " .mysql_real_escape_string(trim($var_id_bastp)). " LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnDetete_bastp=1; } else { $returnDetete_bastp=0; }
	return $returnDetete_bastp;
}

function insert_bastp($var_nomor_bastp,$var_tanggal_bastp,$var_direksi_pekerjaan,$var_direksi_vendor,$var_file_bapp,$var_keterangan,$var_user_input,$var_user_input_date){ 
	$sql="INSERT INTO bastp (id_bastp,nomor_bastp,tanggal_bastp,direksi_pekerjaan,direksi_vendor,file_bapp,keterangan,user_input,user_input_date) VALUES (NULL,'" .mysql_real_escape_string(trim($var_nomor_bastp)). "','" .mysql_real_escape_string(trim($var_tanggal_bastp)). "','" .mysql_real_escape_string(trim($var_direksi_pekerjaan)). "','" .mysql_real_escape_string(trim($var_direksi_vendor)). "','" .mysql_real_escape_string(trim($var_file_bapp)). "','" .mysql_real_escape_string(trim($var_keterangan)). "','" .mysql_real_escape_string(trim($var_user_input)). "','" .mysql_real_escape_string(trim($var_user_input_date)). "')";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnInsert_bastp=1; } else { $returnInsert_bastp=0; }
	return $returnInsert_bastp;
}

function update_bastp($var_id_bastp,$var_nomor_bastp,$var_tanggal_bastp,$var_direksi_pekerjaan,$var_direksi_vendor,$var_file_bapp,$var_keterangan,$var_user_input,$var_user_input_date){ 
	$sql="UPDATE bastp SET nomor_bastp = '" .mysql_real_escape_string(trim($var_nomor_bastp)). "', tanggal_bastp = '" .mysql_real_escape_string(trim($var_tanggal_bastp)). "', direksi_pekerjaan = '" .mysql_real_escape_string(trim($var_direksi_pekerjaan)). "', direksi_vendor = '" .mysql_real_escape_string(trim($var_direksi_vendor)). "', file_bapp = '" .mysql_real_escape_string(trim($var_file_bapp)). "', keterangan = '" .mysql_real_escape_string(trim($var_keterangan)). "', user_input = '" .mysql_real_escape_string(trim($var_user_input)). "', user_input_date = '" .mysql_real_escape_string(trim($var_user_input_date)). "' WHERE id_bastp = '" .mysql_real_escape_string(trim($var_id_bastp)). "' LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnUpdate_bastp=1; } else { $returnUpdate_bastp=0; }
	return $returnUpdate_bastp;
}

?>