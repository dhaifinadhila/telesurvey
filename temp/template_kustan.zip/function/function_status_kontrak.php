<?

function select_status_kontrak(){ 
	$sql="SELECT * FROM status_kontrak" ;
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_id_status_kontrak($var_id_status_kontrak){ 
	$sql="SELECT * FROM status_kontrak WHERE id_status_kontrak = '" .mysql_real_escape_string(trim($var_id_status_kontrak)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_id_spk($var_id_spk){ 
	$sql="SELECT * FROM status_kontrak WHERE id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_nomor_spk($var_nomor_spk){ 
	$sql="SELECT * FROM status_kontrak WHERE nomor_spk = '" .mysql_real_escape_string(trim($var_nomor_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_spk_status($var_spk_status){ 
	$sql="SELECT * FROM status_kontrak WHERE spk_status = '" .mysql_real_escape_string(trim($var_spk_status)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_spk_tanggal($var_spk_tanggal){ 
	$sql="SELECT * FROM status_kontrak WHERE spk_tanggal = '" .mysql_real_escape_string(trim($var_spk_tanggal)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_id_bapp($var_id_bapp){ 
	$sql="SELECT * FROM status_kontrak WHERE id_bapp = '" .mysql_real_escape_string(trim($var_id_bapp)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_nomor_bapp($var_nomor_bapp){ 
	$sql="SELECT * FROM status_kontrak WHERE nomor_bapp = '" .mysql_real_escape_string(trim($var_nomor_bapp)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_bapp_status($var_bapp_status){ 
	$sql="SELECT * FROM status_kontrak WHERE bapp_status = '" .mysql_real_escape_string(trim($var_bapp_status)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_bapp_tanggal($var_bapp_tanggal){ 
	$sql="SELECT * FROM status_kontrak WHERE bapp_tanggal = '" .mysql_real_escape_string(trim($var_bapp_tanggal)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_id_bastp($var_id_bastp){ 
	$sql="SELECT * FROM status_kontrak WHERE id_bastp = '" .mysql_real_escape_string(trim($var_id_bastp)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_nomor_bastp($var_nomor_bastp){ 
	$sql="SELECT * FROM status_kontrak WHERE nomor_bastp = '" .mysql_real_escape_string(trim($var_nomor_bastp)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_bastp_status($var_bastp_status){ 
	$sql="SELECT * FROM status_kontrak WHERE bastp_status = '" .mysql_real_escape_string(trim($var_bastp_status)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_bastp_tanggal($var_bastp_tanggal){ 
	$sql="SELECT * FROM status_kontrak WHERE bastp_tanggal = '" .mysql_real_escape_string(trim($var_bastp_tanggal)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_pr_user($var_pr_user){ 
	$sql="SELECT * FROM status_kontrak WHERE pr_user = '" .mysql_real_escape_string(trim($var_pr_user)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_pr_status($var_pr_status){ 
	$sql="SELECT * FROM status_kontrak WHERE pr_status = '" .mysql_real_escape_string(trim($var_pr_status)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_pr_tanggal($var_pr_tanggal){ 
	$sql="SELECT * FROM status_kontrak WHERE pr_tanggal = '" .mysql_real_escape_string(trim($var_pr_tanggal)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_id_tagihan($var_id_tagihan){ 
	$sql="SELECT * FROM status_kontrak WHERE id_tagihan = '" .mysql_real_escape_string(trim($var_id_tagihan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_po_user($var_po_user){ 
	$sql="SELECT * FROM status_kontrak WHERE po_user = '" .mysql_real_escape_string(trim($var_po_user)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_po_status($var_po_status){ 
	$sql="SELECT * FROM status_kontrak WHERE po_status = '" .mysql_real_escape_string(trim($var_po_status)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_po_tanggal($var_po_tanggal){ 
	$sql="SELECT * FROM status_kontrak WHERE po_tanggal = '" .mysql_real_escape_string(trim($var_po_tanggal)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_se_user($var_se_user){ 
	$sql="SELECT * FROM status_kontrak WHERE se_user = '" .mysql_real_escape_string(trim($var_se_user)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_se_status($var_se_status){ 
	$sql="SELECT * FROM status_kontrak WHERE se_status = '" .mysql_real_escape_string(trim($var_se_status)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_se_tanggal($var_se_tanggal){ 
	$sql="SELECT * FROM status_kontrak WHERE se_tanggal = '" .mysql_real_escape_string(trim($var_se_tanggal)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_id_anggaran($var_id_anggaran){ 
	$sql="SELECT * FROM status_kontrak WHERE id_anggaran = '" .mysql_real_escape_string(trim($var_id_anggaran)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_id_keuangan($var_id_keuangan){ 
	$sql="SELECT * FROM status_kontrak WHERE id_keuangan = '" .mysql_real_escape_string(trim($var_id_keuangan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_status_kontrak_by_keterangan($var_keterangan){ 
	$sql="SELECT * FROM status_kontrak WHERE keterangan = '" .mysql_real_escape_string(trim($var_keterangan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}



function delete_status_kontrak_by_id_status_kontrak($var_id_status_kontrak){ 
	$sql="DELETE FROM status_kontrak WHERE id_status_kontrak = " .mysql_real_escape_string(trim($var_id_status_kontrak)). " LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnDetete_status_kontrak=1; } else { $returnDetete_status_kontrak=0; }
	return $returnDetete_status_kontrak;
}

function insert_status_kontrak($var_id_spk,$var_nomor_spk,$var_spk_status,$var_spk_tanggal,$var_id_bapp,$var_nomor_bapp,$var_bapp_status,$var_bapp_tanggal,$var_id_bastp,$var_nomor_bastp,$var_bastp_status,$var_bastp_tanggal,$var_pr_user,$var_pr_status,$var_pr_tanggal,$var_id_tagihan,$var_po_user,$var_po_status,$var_po_tanggal,$var_se_user,$var_se_status,$var_se_tanggal,$var_id_anggaran,$var_id_keuangan,$var_keterangan){ 
	$sql="INSERT INTO status_kontrak (id_status_kontrak,id_spk,nomor_spk,spk_status,spk_tanggal,id_bapp,nomor_bapp,bapp_status,bapp_tanggal,id_bastp,nomor_bastp,bastp_status,bastp_tanggal,pr_user,pr_status,pr_tanggal,id_tagihan,po_user,po_status,po_tanggal,se_user,se_status,se_tanggal,id_anggaran,id_keuangan,keterangan) VALUES (NULL,'" .mysql_real_escape_string(trim($var_id_spk)). "','" .mysql_real_escape_string(trim($var_nomor_spk)). "','" .mysql_real_escape_string(trim($var_spk_status)). "','" .mysql_real_escape_string(trim($var_spk_tanggal)). "','" .mysql_real_escape_string(trim($var_id_bapp)). "','" .mysql_real_escape_string(trim($var_nomor_bapp)). "','" .mysql_real_escape_string(trim($var_bapp_status)). "','" .mysql_real_escape_string(trim($var_bapp_tanggal)). "','" .mysql_real_escape_string(trim($var_id_bastp)). "','" .mysql_real_escape_string(trim($var_nomor_bastp)). "','" .mysql_real_escape_string(trim($var_bastp_status)). "','" .mysql_real_escape_string(trim($var_bastp_tanggal)). "','" .mysql_real_escape_string(trim($var_pr_user)). "','" .mysql_real_escape_string(trim($var_pr_status)). "','" .mysql_real_escape_string(trim($var_pr_tanggal)). "','" .mysql_real_escape_string(trim($var_id_tagihan)). "','" .mysql_real_escape_string(trim($var_po_user)). "','" .mysql_real_escape_string(trim($var_po_status)). "','" .mysql_real_escape_string(trim($var_po_tanggal)). "','" .mysql_real_escape_string(trim($var_se_user)). "','" .mysql_real_escape_string(trim($var_se_status)). "','" .mysql_real_escape_string(trim($var_se_tanggal)). "','" .mysql_real_escape_string(trim($var_id_anggaran)). "','" .mysql_real_escape_string(trim($var_id_keuangan)). "','" .mysql_real_escape_string(trim($var_keterangan)). "')";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnInsert_status_kontrak=1; } else { $returnInsert_status_kontrak=0; }
	return $returnInsert_status_kontrak;
}

function update_status_kontrak($var_id_status_kontrak,$var_id_spk,$var_nomor_spk,$var_spk_status,$var_spk_tanggal,$var_id_bapp,$var_nomor_bapp,$var_bapp_status,$var_bapp_tanggal,$var_id_bastp,$var_nomor_bastp,$var_bastp_status,$var_bastp_tanggal,$var_pr_user,$var_pr_status,$var_pr_tanggal,$var_id_tagihan,$var_po_user,$var_po_status,$var_po_tanggal,$var_se_user,$var_se_status,$var_se_tanggal,$var_id_anggaran,$var_id_keuangan,$var_keterangan){ 
	$sql="UPDATE status_kontrak SET id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "', nomor_spk = '" .mysql_real_escape_string(trim($var_nomor_spk)). "', spk_status = '" .mysql_real_escape_string(trim($var_spk_status)). "', spk_tanggal = '" .mysql_real_escape_string(trim($var_spk_tanggal)). "', id_bapp = '" .mysql_real_escape_string(trim($var_id_bapp)). "', nomor_bapp = '" .mysql_real_escape_string(trim($var_nomor_bapp)). "', bapp_status = '" .mysql_real_escape_string(trim($var_bapp_status)). "', bapp_tanggal = '" .mysql_real_escape_string(trim($var_bapp_tanggal)). "', id_bastp = '" .mysql_real_escape_string(trim($var_id_bastp)). "', nomor_bastp = '" .mysql_real_escape_string(trim($var_nomor_bastp)). "', bastp_status = '" .mysql_real_escape_string(trim($var_bastp_status)). "', bastp_tanggal = '" .mysql_real_escape_string(trim($var_bastp_tanggal)). "', pr_user = '" .mysql_real_escape_string(trim($var_pr_user)). "', pr_status = '" .mysql_real_escape_string(trim($var_pr_status)). "', pr_tanggal = '" .mysql_real_escape_string(trim($var_pr_tanggal)). "', id_tagihan = '" .mysql_real_escape_string(trim($var_id_tagihan)). "', po_user = '" .mysql_real_escape_string(trim($var_po_user)). "', po_status = '" .mysql_real_escape_string(trim($var_po_status)). "', po_tanggal = '" .mysql_real_escape_string(trim($var_po_tanggal)). "', se_user = '" .mysql_real_escape_string(trim($var_se_user)). "', se_status = '" .mysql_real_escape_string(trim($var_se_status)). "', se_tanggal = '" .mysql_real_escape_string(trim($var_se_tanggal)). "', id_anggaran = '" .mysql_real_escape_string(trim($var_id_anggaran)). "', id_keuangan = '" .mysql_real_escape_string(trim($var_id_keuangan)). "', keterangan = '" .mysql_real_escape_string(trim($var_keterangan)). "' WHERE id_status_kontrak = '" .mysql_real_escape_string(trim($var_id_status_kontrak)). "' LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnUpdate_status_kontrak=1; } else { $returnUpdate_status_kontrak=0; }
	return $returnUpdate_status_kontrak;
}

?>