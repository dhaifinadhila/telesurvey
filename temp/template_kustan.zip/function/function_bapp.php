<?

function select_bapp(){ 
	$sql="SELECT * FROM bapp" ;
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bapp_by_id_bapp($var_id_bapp){ 
	$sql="SELECT * FROM bapp WHERE id_bapp = '" .mysql_real_escape_string(trim($var_id_bapp)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bapp_by_id_spk($var_id_spk){ 
	$sql="SELECT * FROM bapp WHERE id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bapp_by_nomor_bapp($var_nomor_bapp){ 
	$sql="SELECT * FROM bapp WHERE nomor_bapp = '" .mysql_real_escape_string(trim($var_nomor_bapp)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bapp_by_tanggal_bapp($var_tanggal_bapp){ 
	$sql="SELECT * FROM bapp WHERE tanggal_bapp = '" .mysql_real_escape_string(trim($var_tanggal_bapp)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bapp_by_direksi_pekerjaan($var_direksi_pekerjaan){ 
	$sql="SELECT * FROM bapp WHERE direksi_pekerjaan = '" .mysql_real_escape_string(trim($var_direksi_pekerjaan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bapp_by_direksi_vendor($var_direksi_vendor){ 
	$sql="SELECT * FROM bapp WHERE direksi_vendor = '" .mysql_real_escape_string(trim($var_direksi_vendor)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bapp_by_file_bapp($var_file_bapp){ 
	$sql="SELECT * FROM bapp WHERE file_bapp = '" .mysql_real_escape_string(trim($var_file_bapp)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bapp_by_keterangan($var_keterangan){ 
	$sql="SELECT * FROM bapp WHERE keterangan = '" .mysql_real_escape_string(trim($var_keterangan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bapp_by_user_input($var_user_input){ 
	$sql="SELECT * FROM bapp WHERE user_input = '" .mysql_real_escape_string(trim($var_user_input)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_bapp_by_user_input_date($var_user_input_date){ 
	$sql="SELECT * FROM bapp WHERE user_input_date = '" .mysql_real_escape_string(trim($var_user_input_date)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}



function delete_bapp_by_id_bapp($var_id_bapp){ 
	$sql="DELETE FROM bapp WHERE id_bapp = " .mysql_real_escape_string(trim($var_id_bapp)). " LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnDetete_bapp=1; } else { $returnDetete_bapp=0; }
	return $returnDetete_bapp;
}

function insert_bapp($var_id_spk,$var_nomor_bapp,$var_tanggal_bapp,$var_direksi_pekerjaan,$var_direksi_vendor,$var_file_bapp,$var_keterangan,$var_user_input,$var_user_input_date){ 
	$sql="INSERT INTO bapp (id_bapp,id_spk,nomor_bapp,tanggal_bapp,direksi_pekerjaan,direksi_vendor,file_bapp,keterangan,user_input,user_input_date) VALUES (NULL,'" .mysql_real_escape_string(trim($var_id_spk)). "','" .mysql_real_escape_string(trim($var_nomor_bapp)). "','" .mysql_real_escape_string(trim($var_tanggal_bapp)). "','" .mysql_real_escape_string(trim($var_direksi_pekerjaan)). "','" .mysql_real_escape_string(trim($var_direksi_vendor)). "','" .mysql_real_escape_string(trim($var_file_bapp)). "','" .mysql_real_escape_string(trim($var_keterangan)). "','" .mysql_real_escape_string(trim($var_user_input)). "','" .mysql_real_escape_string(trim($var_user_input_date)). "')";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnInsert_bapp=1; } else { $returnInsert_bapp=0; }
	return $returnInsert_bapp;
}

function update_bapp($var_id_bapp,$var_id_spk,$var_nomor_bapp,$var_tanggal_bapp,$var_direksi_pekerjaan,$var_direksi_vendor,$var_file_bapp,$var_keterangan,$var_user_input,$var_user_input_date){ 
	$sql="UPDATE bapp SET id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "', nomor_bapp = '" .mysql_real_escape_string(trim($var_nomor_bapp)). "', tanggal_bapp = '" .mysql_real_escape_string(trim($var_tanggal_bapp)). "', direksi_pekerjaan = '" .mysql_real_escape_string(trim($var_direksi_pekerjaan)). "', direksi_vendor = '" .mysql_real_escape_string(trim($var_direksi_vendor)). "', file_bapp = '" .mysql_real_escape_string(trim($var_file_bapp)). "', keterangan = '" .mysql_real_escape_string(trim($var_keterangan)). "', user_input = '" .mysql_real_escape_string(trim($var_user_input)). "', user_input_date = '" .mysql_real_escape_string(trim($var_user_input_date)). "' WHERE id_bapp = '" .mysql_real_escape_string(trim($var_id_bapp)). "' LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnUpdate_bapp=1; } else { $returnUpdate_bapp=0; }
	return $returnUpdate_bapp;
}

?>