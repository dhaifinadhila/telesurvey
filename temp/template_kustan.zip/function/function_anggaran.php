<?

function select_anggaran(){ 
	$sql="SELECT * FROM anggaran" ;
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_id_anggaran($var_id_anggaran){ 
	$sql="SELECT * FROM anggaran WHERE id_anggaran = '" .mysql_real_escape_string(trim($var_id_anggaran)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_id_spk($var_id_spk){ 
	$sql="SELECT * FROM anggaran WHERE id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_tanggal_masuk($var_tanggal_masuk){ 
	$sql="SELECT * FROM anggaran WHERE tanggal_masuk = '" .mysql_real_escape_string(trim($var_tanggal_masuk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_no_skkio($var_no_skkio){ 
	$sql="SELECT * FROM anggaran WHERE no_skkio = '" .mysql_real_escape_string(trim($var_no_skkio)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_nilai_skkio($var_nilai_skkio){ 
	$sql="SELECT * FROM anggaran WHERE nilai_skkio = '" .mysql_real_escape_string(trim($var_nilai_skkio)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_nomor_spk($var_nomor_spk){ 
	$sql="SELECT * FROM anggaran WHERE nomor_spk = '" .mysql_real_escape_string(trim($var_nomor_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_pembayaran($var_pembayaran){ 
	$sql="SELECT * FROM anggaran WHERE pembayaran = '" .mysql_real_escape_string(trim($var_pembayaran)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_approval_pelaksana($var_approval_pelaksana){ 
	$sql="SELECT * FROM anggaran WHERE approval_pelaksana = '" .mysql_real_escape_string(trim($var_approval_pelaksana)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_approval_pelaksana_status($var_approval_pelaksana_status){ 
	$sql="SELECT * FROM anggaran WHERE approval_pelaksana_status = '" .mysql_real_escape_string(trim($var_approval_pelaksana_status)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_approval_pelaksana_tanggal($var_approval_pelaksana_tanggal){ 
	$sql="SELECT * FROM anggaran WHERE approval_pelaksana_tanggal = '" .mysql_real_escape_string(trim($var_approval_pelaksana_tanggal)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_approval_pelaksana_keterangan($var_approval_pelaksana_keterangan){ 
	$sql="SELECT * FROM anggaran WHERE approval_pelaksana_keterangan = '" .mysql_real_escape_string(trim($var_approval_pelaksana_keterangan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_approval_dm($var_approval_dm){ 
	$sql="SELECT * FROM anggaran WHERE approval_dm = '" .mysql_real_escape_string(trim($var_approval_dm)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_approval_dm_status($var_approval_dm_status){ 
	$sql="SELECT * FROM anggaran WHERE approval_dm_status = '" .mysql_real_escape_string(trim($var_approval_dm_status)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_approval_dm_tanggal($var_approval_dm_tanggal){ 
	$sql="SELECT * FROM anggaran WHERE approval_dm_tanggal = '" .mysql_real_escape_string(trim($var_approval_dm_tanggal)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_anggaran_by_approval_dm_keterangan($var_approval_dm_keterangan){ 
	$sql="SELECT * FROM anggaran WHERE approval_dm_keterangan = '" .mysql_real_escape_string(trim($var_approval_dm_keterangan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}



function delete_anggaran_by_id_anggaran($var_id_anggaran){ 
	$sql="DELETE FROM anggaran WHERE id_anggaran = " .mysql_real_escape_string(trim($var_id_anggaran)). " LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnDetete_anggaran=1; } else { $returnDetete_anggaran=0; }
	return $returnDetete_anggaran;
}

function insert_anggaran($var_id_spk,$var_tanggal_masuk,$var_no_skkio,$var_nilai_skkio,$var_nomor_spk,$var_pembayaran,$var_approval_pelaksana,$var_approval_pelaksana_status,$var_approval_pelaksana_tanggal,$var_approval_pelaksana_keterangan,$var_approval_dm,$var_approval_dm_status,$var_approval_dm_tanggal,$var_approval_dm_keterangan){ 
	$sql="INSERT INTO anggaran (id_anggaran,id_spk,tanggal_masuk,no_skkio,nilai_skkio,nomor_spk,pembayaran,approval_pelaksana,approval_pelaksana_status,approval_pelaksana_tanggal,approval_pelaksana_keterangan,approval_dm,approval_dm_status,approval_dm_tanggal,approval_dm_keterangan) VALUES (NULL,'" .mysql_real_escape_string(trim($var_id_spk)). "','" .mysql_real_escape_string(trim($var_tanggal_masuk)). "','" .mysql_real_escape_string(trim($var_no_skkio)). "','" .mysql_real_escape_string(trim($var_nilai_skkio)). "','" .mysql_real_escape_string(trim($var_nomor_spk)). "','" .mysql_real_escape_string(trim($var_pembayaran)). "','" .mysql_real_escape_string(trim($var_approval_pelaksana)). "','" .mysql_real_escape_string(trim($var_approval_pelaksana_status)). "','" .mysql_real_escape_string(trim($var_approval_pelaksana_tanggal)). "','" .mysql_real_escape_string(trim($var_approval_pelaksana_keterangan)). "','" .mysql_real_escape_string(trim($var_approval_dm)). "','" .mysql_real_escape_string(trim($var_approval_dm_status)). "','" .mysql_real_escape_string(trim($var_approval_dm_tanggal)). "','" .mysql_real_escape_string(trim($var_approval_dm_keterangan)). "')";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnInsert_anggaran=1; } else { $returnInsert_anggaran=0; }
	return $returnInsert_anggaran;
}

function update_anggaran($var_id_anggaran,$var_id_spk,$var_tanggal_masuk,$var_no_skkio,$var_nilai_skkio,$var_nomor_spk,$var_pembayaran,$var_approval_pelaksana,$var_approval_pelaksana_status,$var_approval_pelaksana_tanggal,$var_approval_pelaksana_keterangan,$var_approval_dm,$var_approval_dm_status,$var_approval_dm_tanggal,$var_approval_dm_keterangan){ 
	$sql="UPDATE anggaran SET id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "', tanggal_masuk = '" .mysql_real_escape_string(trim($var_tanggal_masuk)). "', no_skkio = '" .mysql_real_escape_string(trim($var_no_skkio)). "', nilai_skkio = '" .mysql_real_escape_string(trim($var_nilai_skkio)). "', nomor_spk = '" .mysql_real_escape_string(trim($var_nomor_spk)). "', pembayaran = '" .mysql_real_escape_string(trim($var_pembayaran)). "', approval_pelaksana = '" .mysql_real_escape_string(trim($var_approval_pelaksana)). "', approval_pelaksana_status = '" .mysql_real_escape_string(trim($var_approval_pelaksana_status)). "', approval_pelaksana_tanggal = '" .mysql_real_escape_string(trim($var_approval_pelaksana_tanggal)). "', approval_pelaksana_keterangan = '" .mysql_real_escape_string(trim($var_approval_pelaksana_keterangan)). "', approval_dm = '" .mysql_real_escape_string(trim($var_approval_dm)). "', approval_dm_status = '" .mysql_real_escape_string(trim($var_approval_dm_status)). "', approval_dm_tanggal = '" .mysql_real_escape_string(trim($var_approval_dm_tanggal)). "', approval_dm_keterangan = '" .mysql_real_escape_string(trim($var_approval_dm_keterangan)). "' WHERE id_anggaran = '" .mysql_real_escape_string(trim($var_id_anggaran)). "' LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnUpdate_anggaran=1; } else { $returnUpdate_anggaran=0; }
	return $returnUpdate_anggaran;
}

?>