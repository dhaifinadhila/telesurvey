<?

function select_vendor(){ 
	$sql="SELECT * FROM vendor" ;
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_id_vendor($var_id_vendor){ 
	$sql="SELECT * FROM vendor WHERE id_vendor = '" .mysql_real_escape_string(trim($var_id_vendor)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_perusahaan($var_perusahaan){ 
	$sql="SELECT * FROM vendor WHERE perusahaan = '" .mysql_real_escape_string(trim($var_perusahaan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_direktur($var_direktur){ 
	$sql="SELECT * FROM vendor WHERE direktur = '" .mysql_real_escape_string(trim($var_direktur)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_kontak_person($var_kontak_person){ 
	$sql="SELECT * FROM vendor WHERE kontak_person = '" .mysql_real_escape_string(trim($var_kontak_person)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_npwp($var_npwp){ 
	$sql="SELECT * FROM vendor WHERE npwp = '" .mysql_real_escape_string(trim($var_npwp)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_email($var_email){ 
	$sql="SELECT * FROM vendor WHERE email = '" .mysql_real_escape_string(trim($var_email)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_pinbb($var_pinbb){ 
	$sql="SELECT * FROM vendor WHERE pinbb = '" .mysql_real_escape_string(trim($var_pinbb)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_alamat($var_alamat){ 
	$sql="SELECT * FROM vendor WHERE alamat = '" .mysql_real_escape_string(trim($var_alamat)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_handphone($var_handphone){ 
	$sql="SELECT * FROM vendor WHERE handphone = '" .mysql_real_escape_string(trim($var_handphone)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_telephone($var_telephone){ 
	$sql="SELECT * FROM vendor WHERE telephone = '" .mysql_real_escape_string(trim($var_telephone)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_kota($var_kota){ 
	$sql="SELECT * FROM vendor WHERE kota = '" .mysql_real_escape_string(trim($var_kota)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_kodepos($var_kodepos){ 
	$sql="SELECT * FROM vendor WHERE kodepos = '" .mysql_real_escape_string(trim($var_kodepos)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_fax($var_fax){ 
	$sql="SELECT * FROM vendor WHERE fax = '" .mysql_real_escape_string(trim($var_fax)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_sujk($var_sujk){ 
	$sql="SELECT * FROM vendor WHERE sujk = '" .mysql_real_escape_string(trim($var_sujk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_tanggal_sujk($var_tanggal_sujk){ 
	$sql="SELECT * FROM vendor WHERE tanggal_sujk = '" .mysql_real_escape_string(trim($var_tanggal_sujk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_siup($var_siup){ 
	$sql="SELECT * FROM vendor WHERE siup = '" .mysql_real_escape_string(trim($var_siup)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_tanggal_siup($var_tanggal_siup){ 
	$sql="SELECT * FROM vendor WHERE tanggal_siup = '" .mysql_real_escape_string(trim($var_tanggal_siup)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_website($var_website){ 
	$sql="SELECT * FROM vendor WHERE website = '" .mysql_real_escape_string(trim($var_website)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_tanggal_daftar($var_tanggal_daftar){ 
	$sql="SELECT * FROM vendor WHERE tanggal_daftar = '" .mysql_real_escape_string(trim($var_tanggal_daftar)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_bidang_usaha($var_bidang_usaha){ 
	$sql="SELECT * FROM vendor WHERE bidang_usaha = '" .mysql_real_escape_string(trim($var_bidang_usaha)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_status($var_status){ 
	$sql="SELECT * FROM vendor WHERE status = '" .mysql_real_escape_string(trim($var_status)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_user_input($var_user_input){ 
	$sql="SELECT * FROM vendor WHERE user_input = '" .mysql_real_escape_string(trim($var_user_input)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_vendor_by_user_input_date($var_user_input_date){ 
	$sql="SELECT * FROM vendor WHERE user_input_date = '" .mysql_real_escape_string(trim($var_user_input_date)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}



function delete_vendor_by_id_vendor($var_id_vendor){ 
	$sql="DELETE FROM vendor WHERE id_vendor = " .mysql_real_escape_string(trim($var_id_vendor)). " LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnDetete_vendor=1; } else { $returnDetete_vendor=0; }
	return $returnDetete_vendor;
}

function insert_vendor($var_perusahaan,$var_direktur,$var_kontak_person,$var_npwp,$var_email,$var_pinbb,$var_alamat,$var_handphone,$var_telephone,$var_kota,$var_kodepos,$var_fax,$var_sujk,$var_tanggal_sujk,$var_siup,$var_tanggal_siup,$var_website,$var_tanggal_daftar,$var_bidang_usaha,$var_status,$var_user_input,$var_user_input_date){ 
	$sql="INSERT INTO vendor (id_vendor,perusahaan,direktur,kontak_person,npwp,email,pinbb,alamat,handphone,telephone,kota,kodepos,fax,sujk,tanggal_sujk,siup,tanggal_siup,website,tanggal_daftar,bidang_usaha,status,user_input,user_input_date) VALUES (NULL,'" .mysql_real_escape_string(trim($var_perusahaan)). "','" .mysql_real_escape_string(trim($var_direktur)). "','" .mysql_real_escape_string(trim($var_kontak_person)). "','" .mysql_real_escape_string(trim($var_npwp)). "','" .mysql_real_escape_string(trim($var_email)). "','" .mysql_real_escape_string(trim($var_pinbb)). "','" .mysql_real_escape_string(trim($var_alamat)). "','" .mysql_real_escape_string(trim($var_handphone)). "','" .mysql_real_escape_string(trim($var_telephone)). "','" .mysql_real_escape_string(trim($var_kota)). "','" .mysql_real_escape_string(trim($var_kodepos)). "','" .mysql_real_escape_string(trim($var_fax)). "','" .mysql_real_escape_string(trim($var_sujk)). "','" .mysql_real_escape_string(trim($var_tanggal_sujk)). "','" .mysql_real_escape_string(trim($var_siup)). "','" .mysql_real_escape_string(trim($var_tanggal_siup)). "','" .mysql_real_escape_string(trim($var_website)). "','" .mysql_real_escape_string(trim($var_tanggal_daftar)). "','" .mysql_real_escape_string(trim($var_bidang_usaha)). "','" .mysql_real_escape_string(trim($var_status)). "','" .mysql_real_escape_string(trim($var_user_input)). "','" .mysql_real_escape_string(trim($var_user_input_date)). "')";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnInsert_vendor=1; } else { $returnInsert_vendor=0; }
	return $returnInsert_vendor;
}

function update_vendor($var_id_vendor,$var_perusahaan,$var_direktur,$var_kontak_person,$var_npwp,$var_email,$var_pinbb,$var_alamat,$var_handphone,$var_telephone,$var_kota,$var_kodepos,$var_fax,$var_sujk,$var_tanggal_sujk,$var_siup,$var_tanggal_siup,$var_website,$var_tanggal_daftar,$var_bidang_usaha,$var_status,$var_user_input,$var_user_input_date){ 
	$sql="UPDATE vendor SET perusahaan = '" .mysql_real_escape_string(trim($var_perusahaan)). "', direktur = '" .mysql_real_escape_string(trim($var_direktur)). "', kontak_person = '" .mysql_real_escape_string(trim($var_kontak_person)). "', npwp = '" .mysql_real_escape_string(trim($var_npwp)). "', email = '" .mysql_real_escape_string(trim($var_email)). "', pinbb = '" .mysql_real_escape_string(trim($var_pinbb)). "', alamat = '" .mysql_real_escape_string(trim($var_alamat)). "', handphone = '" .mysql_real_escape_string(trim($var_handphone)). "', telephone = '" .mysql_real_escape_string(trim($var_telephone)). "', kota = '" .mysql_real_escape_string(trim($var_kota)). "', kodepos = '" .mysql_real_escape_string(trim($var_kodepos)). "', fax = '" .mysql_real_escape_string(trim($var_fax)). "', sujk = '" .mysql_real_escape_string(trim($var_sujk)). "', tanggal_sujk = '" .mysql_real_escape_string(trim($var_tanggal_sujk)). "', siup = '" .mysql_real_escape_string(trim($var_siup)). "', tanggal_siup = '" .mysql_real_escape_string(trim($var_tanggal_siup)). "', website = '" .mysql_real_escape_string(trim($var_website)). "', tanggal_daftar = '" .mysql_real_escape_string(trim($var_tanggal_daftar)). "', bidang_usaha = '" .mysql_real_escape_string(trim($var_bidang_usaha)). "', status = '" .mysql_real_escape_string(trim($var_status)). "', user_input = '" .mysql_real_escape_string(trim($var_user_input)). "', user_input_date = '" .mysql_real_escape_string(trim($var_user_input_date)). "' WHERE id_vendor = '" .mysql_real_escape_string(trim($var_id_vendor)). "' LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnUpdate_vendor=1; } else { $returnUpdate_vendor=0; }
	return $returnUpdate_vendor;
}

?>