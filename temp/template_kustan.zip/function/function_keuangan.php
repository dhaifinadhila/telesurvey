<?

function select_keuangan(){ 
	$sql="SELECT * FROM keuangan" ;
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_id_keuangan($var_id_keuangan){ 
	$sql="SELECT * FROM keuangan WHERE id_keuangan = '" .mysql_real_escape_string(trim($var_id_keuangan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_id_spk($var_id_spk){ 
	$sql="SELECT * FROM keuangan WHERE id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_tanggal_masuk($var_tanggal_masuk){ 
	$sql="SELECT * FROM keuangan WHERE tanggal_masuk = '" .mysql_real_escape_string(trim($var_tanggal_masuk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_nomor_spk($var_nomor_spk){ 
	$sql="SELECT * FROM keuangan WHERE nomor_spk = '" .mysql_real_escape_string(trim($var_nomor_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_approval_pelaksana($var_approval_pelaksana){ 
	$sql="SELECT * FROM keuangan WHERE approval_pelaksana = '" .mysql_real_escape_string(trim($var_approval_pelaksana)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_approval_pelaksana_status($var_approval_pelaksana_status){ 
	$sql="SELECT * FROM keuangan WHERE approval_pelaksana_status = '" .mysql_real_escape_string(trim($var_approval_pelaksana_status)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_approval_pelaksana_tanggal($var_approval_pelaksana_tanggal){ 
	$sql="SELECT * FROM keuangan WHERE approval_pelaksana_tanggal = '" .mysql_real_escape_string(trim($var_approval_pelaksana_tanggal)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_approval_pelaksana_keterangan($var_approval_pelaksana_keterangan){ 
	$sql="SELECT * FROM keuangan WHERE approval_pelaksana_keterangan = '" .mysql_real_escape_string(trim($var_approval_pelaksana_keterangan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_approval_dm($var_approval_dm){ 
	$sql="SELECT * FROM keuangan WHERE approval_dm = '" .mysql_real_escape_string(trim($var_approval_dm)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_approval_dm_status($var_approval_dm_status){ 
	$sql="SELECT * FROM keuangan WHERE approval_dm_status = '" .mysql_real_escape_string(trim($var_approval_dm_status)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_approval_dm_tanggal($var_approval_dm_tanggal){ 
	$sql="SELECT * FROM keuangan WHERE approval_dm_tanggal = '" .mysql_real_escape_string(trim($var_approval_dm_tanggal)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_approval_dm_keterangan($var_approval_dm_keterangan){ 
	$sql="SELECT * FROM keuangan WHERE approval_dm_keterangan = '" .mysql_real_escape_string(trim($var_approval_dm_keterangan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_approval_mb($var_approval_mb){ 
	$sql="SELECT * FROM keuangan WHERE approval_mb = '" .mysql_real_escape_string(trim($var_approval_mb)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_approval_mb_status($var_approval_mb_status){ 
	$sql="SELECT * FROM keuangan WHERE approval_mb_status = '" .mysql_real_escape_string(trim($var_approval_mb_status)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_keuangan_by_approval_mb_keterangan($var_approval_mb_keterangan){ 
	$sql="SELECT * FROM keuangan WHERE approval_mb_keterangan = '" .mysql_real_escape_string(trim($var_approval_mb_keterangan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}



function delete_keuangan_by_id_keuangan($var_id_keuangan){ 
	$sql="DELETE FROM keuangan WHERE id_keuangan = " .mysql_real_escape_string(trim($var_id_keuangan)). " LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnDetete_keuangan=1; } else { $returnDetete_keuangan=0; }
	return $returnDetete_keuangan;
}

function insert_keuangan($var_id_spk,$var_tanggal_masuk,$var_nomor_spk,$var_approval_pelaksana,$var_approval_pelaksana_status,$var_approval_pelaksana_tanggal,$var_approval_pelaksana_keterangan,$var_approval_dm,$var_approval_dm_status,$var_approval_dm_tanggal,$var_approval_dm_keterangan,$var_approval_mb,$var_approval_mb_status,$var_approval_mb_keterangan){ 
	$sql="INSERT INTO keuangan (id_keuangan,id_spk,tanggal_masuk,nomor_spk,approval_pelaksana,approval_pelaksana_status,approval_pelaksana_tanggal,approval_pelaksana_keterangan,approval_dm,approval_dm_status,approval_dm_tanggal,approval_dm_keterangan,approval_mb,approval_mb_status,approval_mb_keterangan) VALUES (NULL,'" .mysql_real_escape_string(trim($var_id_spk)). "','" .mysql_real_escape_string(trim($var_tanggal_masuk)). "','" .mysql_real_escape_string(trim($var_nomor_spk)). "','" .mysql_real_escape_string(trim($var_approval_pelaksana)). "','" .mysql_real_escape_string(trim($var_approval_pelaksana_status)). "','" .mysql_real_escape_string(trim($var_approval_pelaksana_tanggal)). "','" .mysql_real_escape_string(trim($var_approval_pelaksana_keterangan)). "','" .mysql_real_escape_string(trim($var_approval_dm)). "','" .mysql_real_escape_string(trim($var_approval_dm_status)). "','" .mysql_real_escape_string(trim($var_approval_dm_tanggal)). "','" .mysql_real_escape_string(trim($var_approval_dm_keterangan)). "','" .mysql_real_escape_string(trim($var_approval_mb)). "','" .mysql_real_escape_string(trim($var_approval_mb_status)). "','" .mysql_real_escape_string(trim($var_approval_mb_keterangan)). "')";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnInsert_keuangan=1; } else { $returnInsert_keuangan=0; }
	return $returnInsert_keuangan;
}

function update_keuangan($var_id_keuangan,$var_id_spk,$var_tanggal_masuk,$var_nomor_spk,$var_approval_pelaksana,$var_approval_pelaksana_status,$var_approval_pelaksana_tanggal,$var_approval_pelaksana_keterangan,$var_approval_dm,$var_approval_dm_status,$var_approval_dm_tanggal,$var_approval_dm_keterangan,$var_approval_mb,$var_approval_mb_status,$var_approval_mb_keterangan){ 
	$sql="UPDATE keuangan SET id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "', tanggal_masuk = '" .mysql_real_escape_string(trim($var_tanggal_masuk)). "', nomor_spk = '" .mysql_real_escape_string(trim($var_nomor_spk)). "', approval_pelaksana = '" .mysql_real_escape_string(trim($var_approval_pelaksana)). "', approval_pelaksana_status = '" .mysql_real_escape_string(trim($var_approval_pelaksana_status)). "', approval_pelaksana_tanggal = '" .mysql_real_escape_string(trim($var_approval_pelaksana_tanggal)). "', approval_pelaksana_keterangan = '" .mysql_real_escape_string(trim($var_approval_pelaksana_keterangan)). "', approval_dm = '" .mysql_real_escape_string(trim($var_approval_dm)). "', approval_dm_status = '" .mysql_real_escape_string(trim($var_approval_dm_status)). "', approval_dm_tanggal = '" .mysql_real_escape_string(trim($var_approval_dm_tanggal)). "', approval_dm_keterangan = '" .mysql_real_escape_string(trim($var_approval_dm_keterangan)). "', approval_mb = '" .mysql_real_escape_string(trim($var_approval_mb)). "', approval_mb_status = '" .mysql_real_escape_string(trim($var_approval_mb_status)). "', approval_mb_keterangan = '" .mysql_real_escape_string(trim($var_approval_mb_keterangan)). "' WHERE id_keuangan = '" .mysql_real_escape_string(trim($var_id_keuangan)). "' LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnUpdate_keuangan=1; } else { $returnUpdate_keuangan=0; }
	return $returnUpdate_keuangan;
}

?>