<?

function select_spk_angsuran(){ 
	$sql="SELECT * FROM spk_angsuran" ;
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_angsuran_by_id_spk_angsuran($var_id_spk_angsuran){ 
	$sql="SELECT * FROM spk_angsuran WHERE id_spk_angsuran = '" .mysql_real_escape_string(trim($var_id_spk_angsuran)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_angsuran_by_id_spk($var_id_spk){ 
	$sql="SELECT * FROM spk_angsuran WHERE id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_angsuran_by_persen_angsuran($var_persen_angsuran){ 
	$sql="SELECT * FROM spk_angsuran WHERE persen_angsuran = '" .mysql_real_escape_string(trim($var_persen_angsuran)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_angsuran_by_tanggal_angsuran($var_tanggal_angsuran){ 
	$sql="SELECT * FROM spk_angsuran WHERE tanggal_angsuran = '" .mysql_real_escape_string(trim($var_tanggal_angsuran)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_angsuran_by_rupiah_angsuran($var_rupiah_angsuran){ 
	$sql="SELECT * FROM spk_angsuran WHERE rupiah_angsuran = '" .mysql_real_escape_string(trim($var_rupiah_angsuran)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_angsuran_by_status_bayar($var_status_bayar){ 
	$sql="SELECT * FROM spk_angsuran WHERE status_bayar = '" .mysql_real_escape_string(trim($var_status_bayar)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_angsuran_by_user_input($var_user_input){ 
	$sql="SELECT * FROM spk_angsuran WHERE user_input = '" .mysql_real_escape_string(trim($var_user_input)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_angsuran_by_user_input_date($var_user_input_date){ 
	$sql="SELECT * FROM spk_angsuran WHERE user_input_date = '" .mysql_real_escape_string(trim($var_user_input_date)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}



function delete_spk_angsuran_by_id_spk_angsuran($var_id_spk_angsuran){ 
	$sql="DELETE FROM spk_angsuran WHERE id_spk_angsuran = " .mysql_real_escape_string(trim($var_id_spk_angsuran)). " LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnDetete_spk_angsuran=1; } else { $returnDetete_spk_angsuran=0; }
	return $returnDetete_spk_angsuran;
}

function insert_spk_angsuran($var_id_spk,$var_persen_angsuran,$var_tanggal_angsuran,$var_rupiah_angsuran,$var_status_bayar,$var_user_input,$var_user_input_date){ 
	$sql="INSERT INTO spk_angsuran (id_spk_angsuran,id_spk,persen_angsuran,tanggal_angsuran,rupiah_angsuran,status_bayar,user_input,user_input_date) VALUES (NULL,'" .mysql_real_escape_string(trim($var_id_spk)). "','" .mysql_real_escape_string(trim($var_persen_angsuran)). "','" .mysql_real_escape_string(trim($var_tanggal_angsuran)). "','" .mysql_real_escape_string(trim($var_rupiah_angsuran)). "','" .mysql_real_escape_string(trim($var_status_bayar)). "','" .mysql_real_escape_string(trim($var_user_input)). "','" .mysql_real_escape_string(trim($var_user_input_date)). "')";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnInsert_spk_angsuran=1; } else { $returnInsert_spk_angsuran=0; }
	return $returnInsert_spk_angsuran;
}

function update_spk_angsuran($var_id_spk_angsuran,$var_id_spk,$var_persen_angsuran,$var_tanggal_angsuran,$var_rupiah_angsuran,$var_status_bayar,$var_user_input,$var_user_input_date){ 
	$sql="UPDATE spk_angsuran SET id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "', persen_angsuran = '" .mysql_real_escape_string(trim($var_persen_angsuran)). "', tanggal_angsuran = '" .mysql_real_escape_string(trim($var_tanggal_angsuran)). "', rupiah_angsuran = '" .mysql_real_escape_string(trim($var_rupiah_angsuran)). "', status_bayar = '" .mysql_real_escape_string(trim($var_status_bayar)). "', user_input = '" .mysql_real_escape_string(trim($var_user_input)). "', user_input_date = '" .mysql_real_escape_string(trim($var_user_input_date)). "' WHERE id_spk_angsuran = '" .mysql_real_escape_string(trim($var_id_spk_angsuran)). "' LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnUpdate_spk_angsuran=1; } else { $returnUpdate_spk_angsuran=0; }
	return $returnUpdate_spk_angsuran;
}

?>