<?

function select_spk(){ 
	$sql="SELECT * FROM spk" ;
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_id_spk($var_id_spk){ 
	$sql="SELECT * FROM spk WHERE id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_id_vendor($var_id_vendor){ 
	$sql="SELECT * FROM spk WHERE id_vendor = '" .mysql_real_escape_string(trim($var_id_vendor)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_nama_pekerjaan($var_nama_pekerjaan){ 
	$sql="SELECT * FROM spk WHERE nama_pekerjaan = '" .mysql_real_escape_string(trim($var_nama_pekerjaan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_nomor_spk($var_nomor_spk){ 
	$sql="SELECT * FROM spk WHERE nomor_spk = '" .mysql_real_escape_string(trim($var_nomor_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_tanggal_spk($var_tanggal_spk){ 
	$sql="SELECT * FROM spk WHERE tanggal_spk = '" .mysql_real_escape_string(trim($var_tanggal_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_unit_bidang($var_unit_bidang){ 
	$sql="SELECT * FROM spk WHERE unit_bidang = '" .mysql_real_escape_string(trim($var_unit_bidang)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_pihak_pertama($var_pihak_pertama){ 
	$sql="SELECT * FROM spk WHERE pihak_pertama = '" .mysql_real_escape_string(trim($var_pihak_pertama)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_pihak_kedua($var_pihak_kedua){ 
	$sql="SELECT * FROM spk WHERE pihak_kedua = '" .mysql_real_escape_string(trim($var_pihak_kedua)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_rupiah_spk($var_rupiah_spk){ 
	$sql="SELECT * FROM spk WHERE rupiah_spk = '" .mysql_real_escape_string(trim($var_rupiah_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_tanggal_selesai_kontrak($var_tanggal_selesai_kontrak){ 
	$sql="SELECT * FROM spk WHERE tanggal_selesai_kontrak = '" .mysql_real_escape_string(trim($var_tanggal_selesai_kontrak)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_direksi_pekerjaan($var_direksi_pekerjaan){ 
	$sql="SELECT * FROM spk WHERE direksi_pekerjaan = '" .mysql_real_escape_string(trim($var_direksi_pekerjaan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_pembayaran_diangsur($var_pembayaran_diangsur){ 
	$sql="SELECT * FROM spk WHERE pembayaran_diangsur = '" .mysql_real_escape_string(trim($var_pembayaran_diangsur)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_denda($var_denda){ 
	$sql="SELECT * FROM spk WHERE denda = '" .mysql_real_escape_string(trim($var_denda)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_file_spk($var_file_spk){ 
	$sql="SELECT * FROM spk WHERE file_spk = '" .mysql_real_escape_string(trim($var_file_spk)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_keterangan($var_keterangan){ 
	$sql="SELECT * FROM spk WHERE keterangan = '" .mysql_real_escape_string(trim($var_keterangan)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_user_input($var_user_input){ 
	$sql="SELECT * FROM spk WHERE user_input = '" .mysql_real_escape_string(trim($var_user_input)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}

function select_spk_by_user_input_date($var_user_input_date){ 
	$sql="SELECT * FROM spk WHERE user_input_date = '" .mysql_real_escape_string(trim($var_user_input_date)). "'  ";
	$resultQuery=mysql_query($sql);
	while ($rows=mysql_fetch_row($resultQuery)){ 
		$data[] = $rows;
	}
	return $data;
}



function delete_spk_by_id_spk($var_id_spk){ 
	$sql="DELETE FROM spk WHERE id_spk = " .mysql_real_escape_string(trim($var_id_spk)). " LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnDetete_spk=1; } else { $returnDetete_spk=0; }
	return $returnDetete_spk;
}

function insert_spk($var_id_vendor,$var_nama_pekerjaan,$var_nomor_spk,$var_tanggal_spk,$var_unit_bidang,$var_pihak_pertama,$var_pihak_kedua,$var_rupiah_spk,$var_tanggal_selesai_kontrak,$var_direksi_pekerjaan,$var_pembayaran_diangsur,$var_denda,$var_file_spk,$var_keterangan,$var_user_input,$var_user_input_date){ 
	$sql="INSERT INTO spk (id_spk,id_vendor,nama_pekerjaan,nomor_spk,tanggal_spk,unit_bidang,pihak_pertama,pihak_kedua,rupiah_spk,tanggal_selesai_kontrak,direksi_pekerjaan,pembayaran_diangsur,denda,file_spk,keterangan,user_input,user_input_date) VALUES (NULL,'" .mysql_real_escape_string(trim($var_id_vendor)). "','" .mysql_real_escape_string(trim($var_nama_pekerjaan)). "','" .mysql_real_escape_string(trim($var_nomor_spk)). "','" .mysql_real_escape_string(trim($var_tanggal_spk)). "','" .mysql_real_escape_string(trim($var_unit_bidang)). "','" .mysql_real_escape_string(trim($var_pihak_pertama)). "','" .mysql_real_escape_string(trim($var_pihak_kedua)). "','" .mysql_real_escape_string(trim($var_rupiah_spk)). "','" .mysql_real_escape_string(trim($var_tanggal_selesai_kontrak)). "','" .mysql_real_escape_string(trim($var_direksi_pekerjaan)). "','" .mysql_real_escape_string(trim($var_pembayaran_diangsur)). "','" .mysql_real_escape_string(trim($var_denda)). "','" .mysql_real_escape_string(trim($var_file_spk)). "','" .mysql_real_escape_string(trim($var_keterangan)). "','" .mysql_real_escape_string(trim($var_user_input)). "','" .mysql_real_escape_string(trim($var_user_input_date)). "')";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnInsert_spk=1; } else { $returnInsert_spk=0; }
	return $returnInsert_spk;
}

function update_spk($var_id_spk,$var_id_vendor,$var_nama_pekerjaan,$var_nomor_spk,$var_tanggal_spk,$var_unit_bidang,$var_pihak_pertama,$var_pihak_kedua,$var_rupiah_spk,$var_tanggal_selesai_kontrak,$var_direksi_pekerjaan,$var_pembayaran_diangsur,$var_denda,$var_file_spk,$var_keterangan,$var_user_input,$var_user_input_date){ 
	$sql="UPDATE spk SET id_vendor = '" .mysql_real_escape_string(trim($var_id_vendor)). "', nama_pekerjaan = '" .mysql_real_escape_string(trim($var_nama_pekerjaan)). "', nomor_spk = '" .mysql_real_escape_string(trim($var_nomor_spk)). "', tanggal_spk = '" .mysql_real_escape_string(trim($var_tanggal_spk)). "', unit_bidang = '" .mysql_real_escape_string(trim($var_unit_bidang)). "', pihak_pertama = '" .mysql_real_escape_string(trim($var_pihak_pertama)). "', pihak_kedua = '" .mysql_real_escape_string(trim($var_pihak_kedua)). "', rupiah_spk = '" .mysql_real_escape_string(trim($var_rupiah_spk)). "', tanggal_selesai_kontrak = '" .mysql_real_escape_string(trim($var_tanggal_selesai_kontrak)). "', direksi_pekerjaan = '" .mysql_real_escape_string(trim($var_direksi_pekerjaan)). "', pembayaran_diangsur = '" .mysql_real_escape_string(trim($var_pembayaran_diangsur)). "', denda = '" .mysql_real_escape_string(trim($var_denda)). "', file_spk = '" .mysql_real_escape_string(trim($var_file_spk)). "', keterangan = '" .mysql_real_escape_string(trim($var_keterangan)). "', user_input = '" .mysql_real_escape_string(trim($var_user_input)). "', user_input_date = '" .mysql_real_escape_string(trim($var_user_input_date)). "' WHERE id_spk = '" .mysql_real_escape_string(trim($var_id_spk)). "' LIMIT 1";
	$resultQuery=mysql_query($sql);
	if($resultQuery){ $returnUpdate_spk=1; } else { $returnUpdate_spk=0; }
	return $returnUpdate_spk;
}

?>