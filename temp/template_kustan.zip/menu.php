 
<div id="ddtopmenubar" class="mattblackmenu">
	<ul>
		 <li><a href="home.php">Home</a></li>
		 <li><a href="tabel.php">SPK</a></li>
         <li><a href="tabel.php">BAPP</a></li>
		 <li><a href="tabel.php">BASTP</a></li>
         <li><a href="tabel.php">Anggaran</a></li>
		 <li><a href="tabel.php">Keuangan</a></li>  
		 <li><a href="tabel.php">Status Kontrak</a></li>
         <li><a href="tabel.php">Tagihan</a></li> 
		 <li><a href="#" rel="submenu_datamaster" >Data Master</a></li>
		 <li><a href="tabel.php">&nbsp;&nbsp;Logout&nbsp;&nbsp;</a></li>
	</ul>
</div>

<script type="text/javascript">
	ddlevelsmenu.setup("ddtopmenubar", "topbar") 
</script>

<ul id="submenu_datamaster" class="ddsubmenustyle">
	<li><a href="tabel.php">Pengguna</a></li>
	<li><a href="tabel.php">Vendor</a></li>    
</ul>
 
 
 
 

 

